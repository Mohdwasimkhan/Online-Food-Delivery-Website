# shoppingsite
Watch it on youtube now...
https://www.youtube.com/watch?v=GiWJQOin5dk

Some screenshots from the project

![Screenshot (142)](https://user-images.githubusercontent.com/68517660/138282796-0e46154f-b75f-438c-93a6-e9a56c0681d8.png)





![Screenshot (143)](https://user-images.githubusercontent.com/68517660/138282991-029ba283-88d5-43e9-85b1-c151b832f8a7.png)





![127 0 0 1_5501_index html(iPhone 6_7_8) (1)](https://user-images.githubusercontent.com/68517660/138283072-c5615461-d397-4a16-ad1f-8538dd0104cd.png)





![127 0 0 1_5501_index html(iPhone 6_7_8) (2)](https://user-images.githubusercontent.com/68517660/138283097-b0d813e7-28af-4e54-bfca-f10c03effa8c.png)
